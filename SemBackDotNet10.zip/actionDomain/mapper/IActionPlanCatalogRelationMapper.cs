// Mechanical conversion from Java (mapper/IActionPlanCatalogRelationMapper.java). Complex bodies are marked with TODO.
// وابستگی‌های اعلام‌شده: basicDomain/Common/base هنوز ارسال نشده‌اند.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SemBackDotNet10.actionDomain.model.entity;
using SemBackDotNet10.actionDomain.model.dto;
using SemBackDotNet10.actionDomain.controller.dto;
using SemBackDotNet10.actionDomain.mapper;
using SemBackDotNet10.actionDomain.repository;
using SemBackDotNet10.actionDomain.service.interf;
using SemBackDotNet10.actionDomain.domain;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.context;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.factory;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.handler;



namespace SemBackDotNet10.actionDomain.mapper;

/// <summary>معادل IActionPlanCatalogRelationMapper.java (اینترفیس جاوا) — در C# با پیشوند I.</summary>
public interface IActionPlanCatalogRelationMapper
{
    //    @Mapping(target = "planPeriod", source = "planPeriod")
    // @Mapping(target = "id", ignore = true)
    // @Mapping(target = "mainActionPlanCatalog", source = "parent")
    // @Mapping(target = "relatedActionPlanCatalog", source = "related")
    // @Mapping(target = "createdBy", ignore = true)
    // @Mapping(target = "createdDate", ignore = true)
    // @Mapping(target = "modifiedBy", ignore = true)
    // @Mapping(target = "modifiedDate", ignore = true)
    // @Mapping(target = "version", ignore = true)
    ActionPlanCatalogRelation create(ActionPlanCatalog parent, ActionPlanCatalog related);
}
