// Mechanical conversion from Java (mapper/IActionPlanActivityMapper.java). Complex bodies are marked with TODO.
// وابستگی‌های اعلام‌شده: basicDomain/Common/base هنوز ارسال نشده‌اند.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SemBackDotNet10.actionDomain.model.entity;
using SemBackDotNet10.actionDomain.model.dto;
using SemBackDotNet10.actionDomain.controller.dto;
using SemBackDotNet10.actionDomain.mapper;
using SemBackDotNet10.actionDomain.repository;
using SemBackDotNet10.actionDomain.service.interf;
using SemBackDotNet10.actionDomain.domain;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.context;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.factory;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.handler;



namespace SemBackDotNet10.actionDomain.mapper;

/// <summary>معادل IActionPlanActivityMapper.java (اینترفیس جاوا) — در C# با پیشوند I.</summary>
public interface IActionPlanActivityMapper
{
    // TODO(signature): }) }) ActionPlanActivity cloneActivity(ActionPlanActivity source, @Context ActionPlanCatalog catalog);
    List<ActionPlanActivity> cloneActivities(List<ActionPlanActivity> source, ActionPlanCatalog catalog);
}
