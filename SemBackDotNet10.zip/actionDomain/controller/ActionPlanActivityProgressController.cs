// Mechanical conversion from Java (controller/ActionPlanActivityProgressController.java). Complex bodies are marked with TODO.
// وابستگی‌های اعلام‌شده: basicDomain/Common/base هنوز ارسال نشده‌اند.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SemBackDotNet10.actionDomain.model.entity;
using SemBackDotNet10.actionDomain.model.dto;
using SemBackDotNet10.actionDomain.controller.dto;
using SemBackDotNet10.actionDomain.mapper;
using SemBackDotNet10.actionDomain.repository;
using SemBackDotNet10.actionDomain.service.interf;
using SemBackDotNet10.actionDomain.domain;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.context;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.factory;
using SemBackDotNet10.actionDomain.strategy.confirmStatusHandler.handler;


namespace SemBackDotNet10.actionDomain.controller;

/// <summary>معادل ActionPlanActivityProgressController.java — تزریق وابستگی‌ها با constructor injection انجام شده است.</summary>
public class ActionPlanActivityProgressController
{
    private readonly IActionPlanActivityProgressService _actionPlanActivityProgressService;

    public ActionPlanActivityProgressController(IActionPlanActivityProgressService actionPlanActivityProgressService)
    {
        _actionPlanActivityProgressService = actionPlanActivityProgressService;
    }

    // TODO(ctor): سازنده‌ی جاوا (جز تزریق وابستگی) منتقل نشده است.
    // TODO(signature): ) { this.actionPlanActivityProgressService = actionPlanActivityProgressService; }
    // TODO(signature): ) { SearchDto response = actionPlanActivityProgressService.loadGrid( body, page, size, orderBy, direction ); return new ResponseEntity<>(response, HttpStatus.OK
    // TODO(signature): ) { actionPlanActivityProgressService.updateActivityProgressActualValues(actionPlanActivityProgressList); return new ResponseEntity<>(HttpStatus.OK); }
}
