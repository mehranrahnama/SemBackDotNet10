// Mechanical conversion from Java (service/interf/IMeasureCatalogLogService.java). Complex bodies are marked with TODO.
// وابستگی‌های اعلام‌شده: basicDomain/Common/base هنوز ارسال نشده‌اند.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SemBackDotNet10.measureDomain.model.entity;
using SemBackDotNet10.measureDomain.model.dto;
using SemBackDotNet10.measureDomain.controller.dto;
using SemBackDotNet10.measureDomain.mapper;
using SemBackDotNet10.measureDomain.repository;
using SemBackDotNet10.measureDomain.service.interf;
using SemBackDotNet10.measureDomain.domain;
using SemBackDotNet10.measureDomain.strategy.confirmStatusHandler.context;
using SemBackDotNet10.measureDomain.strategy.confirmStatusHandler.factory;
using SemBackDotNet10.measureDomain.strategy.confirmStatusHandler.handler;
using SemBackDotNet10.Base.Service.Inter;



namespace SemBackDotNet10.measureDomain.service.interf;

/// <summary>معادل IMeasureCatalogLogService.java (اینترفیس جاوا) — در C# با پیشوند I.</summary>
public interface IMeasureCatalogLogService : IBaseService<MeasureCatalogLog,long?,MeasureCatalogLogRepository>
{
    MeasureCatalogLog createMeasureCatalogLog(Measure measure, long? newTashilgarId, long? newModirId);
    MeasureCatalogLog createMeasureCatalogLog(MeasureCatalog measureCatalog, long? newTashilgarId, long? newModirId);
}
