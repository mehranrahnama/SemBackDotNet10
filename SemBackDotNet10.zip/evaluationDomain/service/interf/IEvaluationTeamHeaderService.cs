using global::SemBackDotNet10.Base.Service.Inter;
using SearchDto = global::SemBackDotNet10.Base.model.dto.SearchDto;
// Mechanical conversion from Java (service/interf/IEvaluationTeamHeaderService.java). Complex bodies are marked with TODO.
// وابستگی‌های اعلام‌شده: basicDomain/Common/base هنوز ارسال نشده‌اند.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SemBackDotNet10.evaluationDomain.model.entity;
using SemBackDotNet10.evaluationDomain.model.dto;
using SemBackDotNet10.evaluationDomain.repository;
using SemBackDotNet10.evaluationDomain.service.interf;
using global::Common.model.entity;
using SemBackDotNet10.basicDomain.Model.Entity;
using SemBackDotNet10.basicDomain.Model.Dto;
using SemBackDotNet10.baseDomain.repository;
using SemBackDotNet10.basicDomain.service;
using SemBackDotNet10.actionDomain.model.entity;
using global::Common.repository;
using global::Common.service.interf;
using global::Common.model.dto;
using global::Common.controller.dto;
using SemBackDotNet10.Common.enums;
using SemBackDotNet10.Common.exception;
using global::Common.messages;
using global::Common.repository;
using global::Common.service.interf;
using global::Common.service.impl;
using global::Common.logging;
using global::Common.model.dto;
using global::Common.utils.cartable;
using global::Common.utils.security;
using global::Common.utils.userRoles;


namespace SemBackDotNet10.evaluationDomain.service.interf;

/// <summary>معادل IEvaluationTeamHeaderService.java (اینترفیس جاوا) — در C# با پیشوند I.</summary>
public interface IEvaluationTeamHeaderService : IBaseService<EvaluationTeamHeader,long?,global::SemBackDotNet10.evaluationDomain.repository.IEvaluationTeamHeaderRepository>
{
    EvaluationTeamHeaderDto create(EvaluationTeamHeaderDto evaluationTeamHeaderDto);
    SearchDto findAllMasterRater(int page, int size, string? orderBy, SortDirection direction, string? body);
    EvaluationTeamHeader findByIdOrElseThrow(long? id);
    void deleteMasterRater(long? evaluationTeamHeaderId);
    void editMasterRater(EvaluationTeamHeaderDto evaluationTeamHeaderDto);
    List<EvaluationTeamHeaderLevelDto> getEvaluationPlaningLevel(EvaluationTeamHeaderDto evaluationTeamHeaderDto);
}
